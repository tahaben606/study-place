import React from 'react';
import Home from './app/page';
import './app/global.css';
function App() {
  return (
    <Home />
  );
}

export default App;