"use client"

import { useEffect, useRef, useState } from "react"

export default function YouTubePlayer({ videoId, onEnded }) {
  const playerRef = useRef(null)
  const iframeRef = useRef(null)
  const [isLoaded, setIsLoaded] = useState(false)

  // Load YouTube IFrame API
  useEffect(() => {
    // Only load the API once
    if (window.YT || document.getElementById("youtube-api")) {
      return
    }

    // Create script element
    const tag = document.createElement("script")
    tag.id = "youtube-api"
    tag.src = "https://www.youtube.com/iframe_api"

    // Insert script before first script tag
    const firstScriptTag = document.getElementsByTagName("script")[0]
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag)

    // Define the onYouTubeIframeAPIReady function which will be called by YouTube API
    window.onYouTubeIframeAPIReady = () => {
      setIsLoaded(true)
    }

    return () => {
      // Cleanup if needed
      window.onYouTubeIframeAPIReady = null
    }
  }, [])

  // Initialize player once API is loaded and videoId is provided
  useEffect(() => {
    if (!isLoaded || !videoId) return

    if (playerRef.current) {
      // If player already exists, load new video
      playerRef.current.loadVideoById(videoId)
      return
    }

    // Create a new player
    playerRef.current = new window.YT.Player(`youtube-player-${videoId}`, {
      videoId,
      playerVars: {
        autoplay: 1,
        modestbranding: 1,
        rel: 0,
      },
      events: {
        onStateChange: (event) => {
          // YouTube state 0 means the video ended
          if (event.data === 0 && typeof onEnded === "function") {
            onEnded()
          }
        },
      },
    })

    return () => {
      if (playerRef.current) {
        playerRef.current.destroy()
        playerRef.current = null
      }
    }
  }, [isLoaded, videoId, onEnded])

  return (
    <div className="aspect-video rounded-lg overflow-hidden bg-black">
      <div id={`youtube-player-${videoId}`} className="w-full h-full"></div>
    </div>
  )
}
