"use client"

import { useState, useRef, useEffect } from "react"
import { X, Trash2, Shuffle, Repeat, ChevronUp, GripVertical } from "lucide-react"

export default function VideoQueue({
  queue = [],
  onRemove,
  onPlay,
  onClear,
  onReorder,
  onPlayNext,
  isVisible = false,
  onToggleVisibility,
  activeVideoId,
  repeat = false,
  onToggleRepeat,
  shuffle = false,
  onToggleShuffle,
}) {
  const [draggingIndex, setDraggingIndex] = useState(null)
  const [dragOverIndex, setDragOverIndex] = useState(null)
  const queueRef = useRef(null)

  // Handle drag and drop functionality
  const handleDragStart = (index) => {
    setDraggingIndex(index)
  }

  const handleDragOver = (e, index) => {
    e.preventDefault()
    if (draggingIndex === null) return
    if (dragOverIndex !== index) {
      setDragOverIndex(index)
    }
  }

  const handleDrop = () => {
    if (draggingIndex === null || dragOverIndex === null || draggingIndex === dragOverIndex) {
      resetDragState()
      return
    }

    const newQueue = [...queue]
    const draggedItem = newQueue[draggingIndex]
    newQueue.splice(draggingIndex, 1)
    newQueue.splice(dragOverIndex, 0, draggedItem)

    onReorder(newQueue)
    resetDragState()
  }

  const handleDragEnd = () => {
    resetDragState()
  }

  const resetDragState = () => {
    setDraggingIndex(null)
    setDragOverIndex(null)
  }

  // Add keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (!isVisible) return

      if (e.key === "Escape") {
        onToggleVisibility()
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [isVisible, onToggleVisibility])

  if (!isVisible) return null

  return (
    <div className="bg-zinc-800 rounded-lg p-4 transition-all duration-300 animate-slide-up" ref={queueRef}>
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-medium text-red-400 flex items-center gap-2">
          Video Queue
          <span className="bg-zinc-700 text-xs px-2 py-0.5 rounded-full">{queue.length}</span>
        </h3>

        <div className="flex items-center gap-2">
          <button
            onClick={onToggleShuffle}
            className={`p-1 text-zinc-400 hover:text-white rounded-full transition-colors ${shuffle ? "text-red-500" : ""}`}
            title={shuffle ? "Shuffle on" : "Shuffle off"}
          >
            <Shuffle size={16} />
          </button>

          <button
            onClick={onToggleRepeat}
            className={`p-1 text-zinc-400 hover:text-white rounded-full transition-colors ${repeat ? "text-red-500" : ""}`}
            title={repeat ? "Repeat queue" : "Don't repeat"}
          >
            <Repeat size={16} />
          </button>

          <button
            onClick={onClear}
            className="text-xs text-zinc-400 hover:text-red-400 flex items-center gap-1 p-1 rounded-full hover:bg-zinc-700"
            disabled={queue.length === 0}
            title="Clear queue"
          >
            <Trash2 size={16} />
          </button>

          <button
            onClick={onToggleVisibility}
            className="text-xs text-zinc-400 hover:text-white flex items-center p-1 rounded-full hover:bg-zinc-700"
            title="Hide queue"
          >
            <ChevronUp size={16} />
          </button>
        </div>
      </div>

      {queue.length === 0 ? (
        <p className="text-center py-4 text-zinc-500 text-sm">
          Queue is empty. Add videos by clicking the "Add to Queue" button.
        </p>
      ) : (
        <div className="grid gap-3 max-h-[300px] overflow-y-auto pr-2">
          {queue.map((video, index) => (
            <div
              key={`queue-${video.id}-${index}`}
              className={`flex gap-3 p-2 rounded-lg ${
                draggingIndex === index
                  ? "bg-zinc-600 opacity-70"
                  : dragOverIndex === index
                    ? "border-t-2 border-red-500"
                    : activeVideoId === video.id
                      ? "bg-zinc-700 border-l-2 border-red-500"
                      : "bg-zinc-700 hover:bg-zinc-600"
              } transition-colors`}
              draggable
              onDragStart={() => handleDragStart(index)}
              onDragOver={(e) => handleDragOver(e, index)}
              onDrop={handleDrop}
              onDragEnd={handleDragEnd}
            >
              <div
                className="text-zinc-400 cursor-move flex items-center justify-center hover:text-white"
                title="Drag to reorder"
              >
                <GripVertical size={16} />
              </div>

              <div className="text-zinc-400 font-mono text-sm flex items-center justify-center w-6">{index + 1}</div>

              <img
                src={video.snippet?.thumbnails?.medium?.url || "/placeholder.svg?height=90&width=120"}
                alt=""
                className="w-20 h-12 object-cover rounded cursor-pointer"
                onClick={() => onPlay(video)}
              />

              <div className="flex-1 min-w-0 cursor-pointer" onClick={() => onPlay(video)}>
                <h4 className="font-medium text-sm line-clamp-1">{video.snippet?.title || "Untitled"}</h4>
                <p className="text-zinc-400 text-xs">{video.snippet?.channelTitle || "Unknown"}</p>
              </div>

              <button
                className="text-zinc-500 hover:text-red-500 self-center p-1"
                onClick={() => onRemove(video.id)}
                title="Remove from queue"
              >
                <X size={16} />
              </button>
            </div>
          ))}
        </div>
      )}

      {queue.length > 0 && (
        <div className="mt-3 flex justify-end">
          <button
            onClick={onPlayNext}
            className="bg-red-600 hover:bg-red-700 text-sm text-white py-1 px-4 rounded-lg transition-colors"
          >
            Play Next
          </button>
        </div>
      )}
    </div>
  )
}
