"use client"

import { useState, useEffect, useCallback } from "react"
import axios from "axios"
import { Play, Search, Plus, X, List, BookOpen, GraduationCap, Clock, AlertCircle, Video } from "lucide-react"

export default function VideoStation({ onAddVideo, onAddToQueue, educationalFocus = false }) {
  const [query, setQuery] = useState("")
  const [videos, setVideos] = useState([])
  const [shorts, setShorts] = useState([])
  const [selectedVideo, setSelectedVideo] = useState(null)
  const [isLoading, setIsLoading] = useState(false)
  const [searchType, setSearchType] = useState("all") // all, lectures, tutorials, pomodoro
  const [error, setError] = useState("")
  const [apiKey, setApiKey] = useState("")

  // Get API key from environment variable
  useEffect(() => {
    const key = process.env.NEXT_PUBLIC_YOUTUBE_API_KEY
    if (key) {
      setApiKey(key)
    }
  }, [])

  const handleSearch = useCallback(async () => {
    if (!query.trim()) {
      setError("Please enter a search term")
      return
    }

    if (!apiKey) {
      setError("YouTube API key is missing")
      return
    }

    setError("")
    setIsLoading(true)

    try {
      // Modify the search query based on the search type
      let searchQuery = query
      if (educationalFocus) {
        if (searchType === "lectures") {
          searchQuery = `${query} lecture educational`
        } else if (searchType === "tutorials") {
          searchQuery = `${query} tutorial how to`
        } else if (searchType === "pomodoro") {
          searchQuery = `pomodoro timer study with me ${query}`
        }
      }

      const res = await axios.get("https://www.googleapis.com/youtube/v3/search", {
        params: {
          part: "snippet",
          maxResults: 25,
          key: apiKey,
          q: searchQuery,
          type: "video",
          videoDuration: searchType === "pomodoro" ? "long" : "any",
        },
      })

      if (res.data.items && Array.isArray(res.data.items)) {
        // Separate videos into regular videos and shorts
        // For demonstration, we'll consider videos with "short" in the title as shorts
        // In a real app, you might want to use the YouTube API to determine if a video is a short
        const regularVideos = []
        const shortVideos = []

        res.data.items.forEach((video) => {
          const title = video.snippet?.title?.toLowerCase() || ""
          const description = video.snippet?.description?.toLowerCase() || ""

          // Consider videos with "short", "#shorts", or similar in title/description as shorts
          // Or videos with square thumbnails (if available)
          if (
            title.includes("short") ||
            description.includes("short") ||
            title.includes("#shorts") ||
            description.includes("#shorts")
          ) {
            shortVideos.push(video)
          } else {
            regularVideos.push(video)
          }
        })

        setVideos(regularVideos)
        setShorts(shortVideos)

        if (res.data.items.length === 0) {
          setError("No videos found. Try a different search term.")
        }
      } else {
        setError("Invalid response from YouTube API")
        setVideos([])
        setShorts([])
      }
    } catch (err) {
      console.error("Error fetching videos:", err)
      setError(err.response?.data?.error?.message || "Error searching videos. Please try again.")
      setVideos([])
      setShorts([])
    } finally {
      setIsLoading(false)
    }
  }, [query, apiKey, educationalFocus, searchType])

  const handleVideoClick = useCallback(
    async (videoId) => {
      if (!apiKey) {
        setError("YouTube API key is missing")
        return
      }

      setError("")
      try {
        const detailRes = await axios.get("https://www.googleapis.com/youtube/v3/videos", {
          params: {
            part: "snippet,statistics,contentDetails",
            id: videoId,
            key: apiKey,
          },
        })

        if (detailRes.data.items && detailRes.data.items.length > 0) {
          const videoData = detailRes.data.items[0]
          setSelectedVideo(videoData)
        } else {
          setError("Video details not found")
        }
      } catch (err) {
        console.error("Error loading video details:", err)
        setError("Error loading video details. Please try again.")
      }
    },
    [apiKey],
  )

  const closeModal = useCallback(() => {
    setSelectedVideo(null)
  }, [])

  const handleAddToHome = useCallback(
    (isShort = false) => {
      if (selectedVideo && typeof onAddVideo === "function") {
        onAddVideo(selectedVideo, isShort)
        closeModal()
      }
    },
    [selectedVideo, onAddVideo, closeModal],
  )

  const handleAddToQueue = useCallback(() => {
    if (selectedVideo && typeof onAddToQueue === "function") {
      onAddToQueue(selectedVideo)
      closeModal()
    }
  }, [selectedVideo, onAddToQueue, closeModal])

  // Function to directly add a video without opening the modal
  const handleQuickAdd = useCallback(
    (video, isShort = false) => {
      if (video && typeof onAddVideo === "function") {
        // Convert the search result format to match the expected format
        const videoData = {
          id: video.id.videoId,
          snippet: video.snippet,
          statistics: { viewCount: "0" }, // Default values
        }
        onAddVideo(videoData, isShort)
      }
    },
    [onAddVideo],
  )

  // Function to directly add a video to queue without opening the modal
  const handleQuickAddToQueue = useCallback(
    (video) => {
      if (video && typeof onAddToQueue === "function") {
        // Convert the search result format to match the expected format
        const videoData = {
          id: video.id.videoId,
          snippet: video.snippet,
          statistics: { viewCount: "0" }, // Default values
        }
        onAddToQueue(videoData)
      }
    },
    [onAddToQueue],
  )

  return (
    <div className="video-station">
      <div className="search-bar flex flex-col gap-2 mb-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              placeholder={educationalFocus ? "Search for educational videos..." : "Search YouTube..."}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              className="w-full bg-zinc-800 border border-zinc-700 rounded-lg py-3 px-4 pl-10 text-white focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-zinc-500" size={18} />
          </div>
          <button
            onClick={handleSearch}
            className="bg-red-600 hover:bg-red-700 text-white font-medium py-3 px-6 rounded-lg transition-colors"
            disabled={isLoading || !query.trim()}
          >
            {isLoading ? "Searching..." : "Search"}
          </button>
        </div>

        {educationalFocus && (
          <div className="flex gap-2">
            <button
              onClick={() => setSearchType("all")}
              className={`flex-1 py-2 px-3 rounded-lg transition-colors flex items-center justify-center gap-1 ${
                searchType === "all" ? "bg-red-600 text-white" : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700"
              }`}
            >
              <Search size={16} />
              All
            </button>
            <button
              onClick={() => setSearchType("lectures")}
              className={`flex-1 py-2 px-3 rounded-lg transition-colors flex items-center justify-center gap-1 ${
                searchType === "lectures" ? "bg-red-600 text-white" : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700"
              }`}
            >
              <GraduationCap size={16} />
              Lectures
            </button>
            <button
              onClick={() => setSearchType("tutorials")}
              className={`flex-1 py-2 px-3 rounded-lg transition-colors flex items-center justify-center gap-1 ${
                searchType === "tutorials" ? "bg-red-600 text-white" : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700"
              }`}
            >
              <BookOpen size={16} />
              Tutorials
            </button>
            <button
              onClick={() => setSearchType("pomodoro")}
              className={`flex-1 py-2 px-3 rounded-lg transition-colors flex items-center justify-center gap-1 ${
                searchType === "pomodoro" ? "bg-red-600 text-white" : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700"
              }`}
            >
              <Clock size={16} />
              Pomodoro
            </button>
          </div>
        )}

        {error && (
          <div className="bg-red-900/30 text-red-400 p-2 rounded-lg flex items-center gap-2 text-sm">
            <AlertCircle size={16} />
            {error}
          </div>
        )}
      </div>

      <div className="overflow-y-auto pr-2 max-h-[600px]">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-red-500"></div>
          </div>
        ) : videos.length > 0 || shorts.length > 0 ? (
          <div className="space-y-6">
            {/* Regular Videos - 5 videos stacked vertically */}
            {videos.length > 0 && (
              <div className="space-y-4">
                <h3 className="font-medium text-zinc-400">Videos</h3>
                <div className="space-y-3">
                  {videos.slice(0, 5).map((video) => (
                    <div
                      key={video.id.videoId}
                      className="flex gap-3 p-3 rounded-lg cursor-pointer hover:bg-zinc-800 transition-colors bg-zinc-800/50"
                    >
                      <img
                        src={
                          video.snippet?.thumbnails?.medium?.url ||
                          video.snippet?.thumbnails?.default?.url ||
                          "/placeholder.svg?height=90&width=120" ||
                          "/placeholder.svg"
                        }
                        alt=""
                        className="w-32 h-20 object-cover rounded"
                        onClick={() => handleVideoClick(video.id.videoId)}
                      />
                      <div className="flex-1 min-w-0" onClick={() => handleVideoClick(video.id.videoId)}>
                        <h4 className="font-medium text-sm line-clamp-2">{video.snippet?.title || "Untitled"}</h4>
                        <p className="text-zinc-400 text-xs">{video.snippet?.channelTitle || "Unknown Channel"}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <button
                            className="text-zinc-400 hover:text-green-500 text-xs flex items-center gap-1"
                            onClick={(e) => {
                              e.stopPropagation()
                              handleVideoClick(video.id.videoId)
                            }}
                          >
                            <Play size={14} /> Play
                          </button>
                          <button
                            className="text-zinc-400 hover:text-blue-500 text-xs flex items-center gap-1"
                            onClick={(e) => {
                              e.stopPropagation()
                              handleQuickAddToQueue(video)
                            }}
                          >
                            <Plus size={14} /> Queue
                          </button>
                          <button
                            className="text-zinc-400 hover:text-red-500 text-xs flex items-center gap-1"
                            onClick={(e) => {
                              e.stopPropagation()
                              handleQuickAdd(video, false)
                            }}
                          >
                            <Video size={14} /> Save
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                  {videos.length > 5 && (
                    <button
                      className="w-full py-2 text-center text-zinc-400 hover:text-white text-sm bg-zinc-800/50 hover:bg-zinc-800 rounded-lg transition-colors"
                      onClick={() => handleSearch()}
                    >
                      Show {videos.length - 5} more videos
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Shorts - 6 videos side by side */}
            {shorts.length > 0 && (
              <div className="mt-6">
                <h3 className="font-medium text-zinc-400 mb-3">Shorts</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
                  {shorts.slice(0, 6).map((video) => (
                    <div
                      key={video.id.videoId}
                      className="flex flex-col rounded-lg cursor-pointer hover:bg-zinc-800 transition-colors overflow-hidden bg-zinc-800/50"
                    >
                      <div className="relative" onClick={() => handleVideoClick(video.id.videoId)}>
                        <img
                          src={
                            video.snippet?.thumbnails?.high?.url ||
                            video.snippet?.thumbnails?.default?.url ||
                            "/placeholder.svg?height=120&width=120" ||
                            "/placeholder.svg"
                          }
                          alt=""
                          className="w-full aspect-square object-cover"
                        />
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity bg-black/50">
                          <Play size={24} className="text-white" />
                        </div>
                      </div>
                      <div className="p-2">
                        <h4 className="text-xs font-medium line-clamp-1">{video.snippet?.title || "Untitled"}</h4>
                        <div className="flex items-center justify-between mt-2">
                          <button
                            className="text-zinc-400 hover:text-blue-500"
                            onClick={(e) => {
                              e.stopPropagation()
                              handleQuickAddToQueue(video)
                            }}
                            title="Add to queue"
                          >
                            <Plus size={14} />
                          </button>
                          <button
                            className="text-zinc-400 hover:text-amber-500"
                            onClick={(e) => {
                              e.stopPropagation()
                              handleQuickAdd(video, true)
                            }}
                            title="Save as short"
                          >
                            <Video size={14} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : query ? (
          <div className="empty-state text-center py-6">
            <div className="text-zinc-500">
              <Search size={36} className="mx-auto mb-3 opacity-50" />
              <p>No videos found for "{query}"</p>
              <p className="text-sm mt-2">Try different keywords or search terms</p>
            </div>
          </div>
        ) : (
          <div className="empty-state text-center py-6">
            <div className="text-zinc-500">
              {educationalFocus ? (
                <>
                  <GraduationCap size={36} className="mx-auto mb-3 opacity-50" />
                  <p className="text-sm">Search for educational videos to get started</p>
                </>
              ) : (
                <>
                  <Search size={36} className="mx-auto mb-3 opacity-50" />
                  <p className="text-sm">Search for videos to get started</p>
                </>
              )}
            </div>
          </div>
        )}
      </div>

      {selectedVideo && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="video-modal-content bg-zinc-900 rounded-xl overflow-hidden max-w-4xl w-full max-h-[90vh] flex flex-col">
            <div className="flex justify-between items-center p-4 border-b border-zinc-800">
              <h3 className="font-bold text-lg line-clamp-1">{selectedVideo.snippet?.title || "Video"}</h3>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  closeModal()
                }}
                className="text-zinc-400 hover:text-white p-1 rounded-full hover:bg-zinc-800 transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            <div className="overflow-y-auto flex-1">
              <div className="aspect-video w-full">
                <iframe
                  width="100%"
                  height="100%"
                  src={`https://www.youtube.com/embed/${selectedVideo.id}?autoplay=1`}
                  title={selectedVideo.snippet?.title || "YouTube Video"}
                  frameBorder="0"
                  allow="autoplay; encrypted-media"
                  allowFullScreen
                  className="w-full h-full"
                ></iframe>
              </div>

              <div className="p-4">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <p className="text-zinc-400">
                      <strong>Channel:</strong> {selectedVideo.snippet?.channelTitle || "Unknown Channel"}
                    </p>
                    <p className="text-zinc-400">
                      <strong>Views:</strong>{" "}
                      {selectedVideo.statistics?.viewCount
                        ? Number.parseInt(selectedVideo.statistics.viewCount).toLocaleString()
                        : "Unknown"}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      className="flex items-center gap-2 bg-zinc-700 hover:bg-zinc-600 text-white font-medium py-2 px-4 rounded-lg transition-colors"
                      onClick={handleAddToQueue}
                    >
                      <List size={18} />
                      Add to Queue
                    </button>
                    <button
                      className="flex items-center gap-2 bg-amber-600 hover:bg-amber-700 text-white font-medium py-2 px-4 rounded-lg transition-colors"
                      onClick={() => handleAddToHome(true)}
                    >
                      <Video size={18} />
                      Save as Short
                    </button>
                    <button
                      className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded-lg transition-colors"
                      onClick={() => handleAddToHome(false)}
                    >
                      <Plus size={18} />
                      Save Video
                    </button>
                  </div>
                </div>

                <div className="bg-zinc-800 p-4 rounded-lg">
                  <p className="text-sm whitespace-pre-line">
                    {selectedVideo.snippet?.description || "No description available."}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
